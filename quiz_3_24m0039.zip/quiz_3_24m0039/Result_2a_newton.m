x0 = [3; 4]; % Initial starting point
N = 25; % Maximum number of iterations

% Run the Newton method
x_min = Newton(@Problem_2a_newtons, x0, N);

disp('The local minimum is located at:');
disp(x_min);