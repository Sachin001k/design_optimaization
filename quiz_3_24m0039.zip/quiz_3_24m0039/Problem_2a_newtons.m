function [fx,Dfx,DDfx] = Problem_2a_newtons(x1,x2)
syms x1 x2
fx = x1^3-18*x1+3*x2-4*x2^2; %Define the function whose roots need to be computed
Dfx=[diff(fx,x1,1);diff(fx,x2,1)]; %First derivative of the above function
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ]; %Hessian matrix
end