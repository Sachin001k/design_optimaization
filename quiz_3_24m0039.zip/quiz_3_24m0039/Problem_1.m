function [fx,Dfx] = Problem_1(x1,x2,alpha1,alpha2,s1,s2)
syms x1 x2 alpha2,s1,s2
fx=3*x1+4*x2-2*x1^3-3*x2^2+alpha1*(2*x1+4*x2-7+s1^2)+alpha2*(4*x1+3*x2-11+s2^2);%Define the function whose roots need to be computed
Dfx=[diff(fx,x1,1);diff(fx,x2,1);diff(fx,alpha1,1);diff(fx,alpha2,1);diff(fx,s1,1);diff(fx,s2,1)];%First derivative of the above function
end