clear
syms x1 x2 alpha1 alpha2 s1 s2
[fx,dfx]=Problem_1(x1,x2,alpha1, alpha2, s1, s2);
eqn1=dfx(1)==0;
eqn2=dfx(2)==0;
eqn3=dfx(3)==0;
eqn4=dfx(4)==0;
eqn5=dfx(5)==0;
eqn6=dfx(6)==0;
S=solve([eqn1,eqn2,eqn3,eqn4,eqn5,eqn6],[x1,x2,alpha1, alpha2, s1, s2]);
x1=double(S.x1);
x2=double(S.x2);
alpha1=double(S.alpha1);
alpha2=double(S.alpha2);
s1=double(S.s1)
s2=double(S.s2)
x=[x1 x2 alpha1 alpha2]
roots=check_gamma1(x,s1,s2)