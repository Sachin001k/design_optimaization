function gamma1=check_gamma1(root,s1,s2)
 
n=max(size(s1));
j=1;
for k=1:n,
    if (imag(s2(k))==0 && imag(s1(k))==0 ),
        for i=1:4,
        gamma1(j,i)=root(k,i);
        end
        j=j+1;
    end
end
end