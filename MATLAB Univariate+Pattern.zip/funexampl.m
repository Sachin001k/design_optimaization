function [fx] = funexampl(x1,x2)
fx=5.5*x1-2*x2+6*x1^2+3*x2^2+4*x1*x2;
end

