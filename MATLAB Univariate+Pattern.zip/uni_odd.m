function x1=uni_odd(f1,xo,eps)
%This function is for changing the values along the horizontal direction
syms gamma1
f0p=f1(xo(1)+eps,xo(2));
f0m=f1(xo(1)-eps,xo(2));
s=check_ep(f0p,f0m);
s1=[s
    0];
x1=xo+gamma1*s1;
fg1=f1(x1(1),x1(2));
fg1d=diff(fg1,gamma1,1);
gamma2=double(solve(fg1d));
x1=xo+max(gamma2)*s1;
end

