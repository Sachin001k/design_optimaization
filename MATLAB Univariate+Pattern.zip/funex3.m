function fx=funex3(x1, x2)
fx=6*x1^2+3*x2^2+3.5*x1^2*x2+4*x1*x2+5.5*x1-2*x2;
end