function x3 = univariate_pattern(f1,x0,N,eps1,eps2)
%f1 function X1
%x0  starting vector
%Number of steps
%eps1: tolerance for search directio
%eps2: tolerance for the optimum value
%y=(@your_function,starting vector, number of steps, eps1,eps2)
X(:,1)=x0;
x01=x0
N=3*round(N/3);%convert N to multiples of 3
for k=1:N/3
for j=1:3,
    %=======================
    k
    j
if j==1,x1=uni_odd(f1,x0,eps1);
x0=x1;
x1
disp('horizontal direction')
pause
end
 %============================
if j==2,x2=uni_even(f1,x0,eps1);
x0=x2;
x2
disp('vertical direction')
pause
end
%====================================
if j==3,x3=pattern1(f1,x2,x01,eps1);
    x0=x3;x01=x3;
    x3
    disp('Pattern search')
pause
if (norm((x3-x2),2)<eps2),break, end
end
end
end
%=========================
end
