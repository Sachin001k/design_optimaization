function [fx,delfx,H] = funex2(x1,x2)
fx=6*x1^2+3*x2^2+3.5*x1^2*x2+4*x1*x2+5.5*x1-2*x2
delfx=[12*x1+7*x1*x2+4*x2+5.5
    6*x2+3.5*x1^2+4*x1-2];
H=[12+7*x2  7*x1+4
    7*x1+4 6];
end

