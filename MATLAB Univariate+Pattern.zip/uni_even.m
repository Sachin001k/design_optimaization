function x1=uni_even(f1,xo,eps)
%This function is for changing the values along the vertical direction
syms gamma1
f0p=f1(xo(1),xo(2)+eps);
f0m=f1(xo(1),xo(2)-eps);
s=check_ep(f0p,f0m);
s1=[0
    s];
x1=xo+gamma1*s1;
fg1=f1(x1(1),x1(2));
fg1d=diff(fg1,gamma1,1);
gamma2=double(solve(fg1d));
x1=xo+max(gamma2)*s1;
end

