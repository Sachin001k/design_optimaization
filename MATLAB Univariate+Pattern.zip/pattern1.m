function x3 = pattern1(f1,x2,xo,eps)
%Use the direction obtained from one cycle of univariate search
syms gamma1
s=x2-xo;
x31=x2+eps*s;
x32=x2-eps*s;
f0p=f1(x31(1),x31(2));
f0m=f1(x32(1),x32(2));
sign=check_ep(f0p,f0m);
s=sign*s;
x3=x2+gamma1*s;
fg=f1(x3(1),x3(2));
fgd=diff(fg,gamma1,1);
gamma1=double(solve(fgd));
x3=x2+max(gamma1)*s;
end

