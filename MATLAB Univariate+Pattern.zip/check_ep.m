function ep= check_ep(f1p,f1m)
if f1p<f1m,ep=1;,elseif f1p>f1m,ep=-1;end
end

