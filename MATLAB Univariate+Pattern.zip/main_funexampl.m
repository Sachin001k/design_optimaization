clear
x3=univariate_pattern(@funexampl ,[0,0],31,0.01,0.001)