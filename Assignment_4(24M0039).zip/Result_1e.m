x0 = [-2,0]; %initial guess
N = 100;

% Steepest descent to find the minima
x_min = Steepest_descent(@Problem_1e,x0,N);

% displaying the result
disp('The local minima is at: ');
disp(x_min);