function [fx, dfx] = Problem_1b(x1, x2)
    % The given function
    fx = (10*x1^3-10*x1-x2-2)^2 + (2*x2^3-10*x2-x1-3)^2;

    % Compute the gradient (symbolically)
    dfx1 = diff(fx, x1);
    dfx2 = diff(fx, x2);
    dfx = [dfx1; dfx2];
end
