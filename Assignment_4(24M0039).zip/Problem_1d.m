function [fx,dfx] = Problem_1d(x1,x2)

% Given function
fx = (x1^2+x2-11)^2+(x1+x2^2-7)^2;

% gradient
dfx1 = diff(fx,x1);
dfx2 =diff(fx,x2);

dfx = [dfx1,dfx2];

end