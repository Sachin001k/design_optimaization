function [fx, dfx] = Problem_1a(x1, x2)
    % The given function
    fx = (3*x1^2 + 12*x2^2 + 10*x1)^2 + (24*x1*x2 + 4*x2 + 3)^2;

    % Compute the gradient (symbolically)
    dfx1 = diff(fx, x1);
    dfx2 = diff(fx, x2);
    dfx = [dfx1; dfx2];
end
