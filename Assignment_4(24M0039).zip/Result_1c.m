x0 = [1,1]; % initial guess
N = 100; % Total number of iterations

% Steepest descent for minima
x_min = Steepest_descent(@Problem_1c,x0,N);

% displaying the result
disp('The local minima is located at');
disp(x_min);