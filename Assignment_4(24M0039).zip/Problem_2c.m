function [fx,Dfx,DDfx] = Problem_2c(x1,x2)
syms x1 x2
fx = (x1^2+x2^2-2)^2+(10*x1^2-10*x2-5*x1+1)^2;

%First derivative of the above function

Dfx=[diff(fx,x1,1);diff(fx,x2,1)]; 
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ]; %Hessian matrix
end