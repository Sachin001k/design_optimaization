function [fx,dfx] = Problem_1c(x1,x2)

% given function
fx = (x1^2+x2^2-2)^2+(10*x1^2-10*x2-5*x1+1)^2;
dfx1 = diff(fx,x1);
dfx2 = diff(fx,x2);
dfx = [dfx1,dfx2];

end