x0 = [1; 1]; % Initial starting point
N = 100; % Maximum number of iterations

% Run the steepest descent method
x_min = Newton(@Problem_2a, x0, N);

disp('The local minimum is located at:');
disp(x_min);