function [fx,Dfx,DDfx] = Problem_2a(x1,x2)
syms x1 x2
fx = (3*x1^2 + 12*x2^2 + 10*x1)^2 + (24*x1*x2 + 4*x2 + 3)^2; %Define the function whose roots need to be computed
Dfx=[diff(fx,x1,1);diff(fx,x2,1)]; %First derivative of the above function
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ]; %Hessian matrix
end