function s= direction(f1,x0,delfx)
%x0:Variable
%dfx:gradient
syms gamma1 x1 x2
s=-delfx;%set the search direction as the negative of the gradient
sd=norm(s,2);%determine the length of the search vector
s=s/sd%unit vector
x(1)=x0(1)+gamma1*s(1);%compute the next value in terms of gamma
x(2)=x0(2)+gamma1*s(2);%compute the next value in terms of gamma
fx=f1(x1,x2);
x1=x(1);
x2=x(2);
fg1=eval(fx);
%fg1=f1(x1(1),x1(2))%calculate the function at x1
fg1d=diff(fg1,gamma1,1);%compute the derivative with respect to gamma1
%gamma1=max(double(solve(fg1d)));%solve for gamma by equating fg1d=0
gamma1=double(solve(fg1d));
gamma1=max(gamma1(gamma1==real(gamma1)))
s=s*gamma1;%obtain the direction
%===========
end
