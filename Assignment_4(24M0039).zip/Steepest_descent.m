function x = Steepest_descent(f1,x0,N)
%program to determine the minimum of a function
%f1:name of the function; it will take the name of your function
%x0:starting vectors
%N:number of iterations
%you should call as follows
%y=Steepest_descent(@your_function_name, starting vector, number of iterations)
syms x1 x2
[fx0,Dfx]=f1(x1,x2);%obtain your function and its first derivative in the symbolic form
eps=0.0001;
for k=1:N,
    disp("Iteration number")
    k
    x1=x0(1)
    x2=x0(2)
    fx=eval(fx0)%evaluate the numerical value of the function at x=x0
    dfx=eval(Dfx)%evaluate the numerical value of the first derivative at x=x0
    s=direction(f1,[x1;x2],dfx);
    x1=x0(1)+s(1)
    x2=x0(2)+s(2)
    x=[x1;x2];
   
    clc %clear screen
    if norm((x-x0),2)<eps,break,end;%check for convergence and break the loop
    x0=x;%reset the starting value and continue the iteration
end
clc

disp("Final value")
y=x1
 disp("Total number of iterations")
    k