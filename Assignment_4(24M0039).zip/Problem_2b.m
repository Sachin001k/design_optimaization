function [fx,Dfx,DDfx] = Problem_2b(x1,x2)
syms x1 x2
fx = (10*x1^3-10*x1-x2-2)^2 + (2*x2^3-10*x2-x1-3)^2;

%First derivative of the above function

Dfx=[diff(fx,x1,1);diff(fx,x2,1)]; 
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ]; %Hessian matrix
end