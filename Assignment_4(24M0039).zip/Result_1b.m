x0 = [0,1]; %initial guess
N = 100; % total number of iterations

% Steepest descent to find the minima
x_min = Steepest_descent(@Problem_1b,x0,N);

disp('The local minima is located at : ');
disp(x_min);

