clear
y=Marquardt(@fun_324_Arora,[5;-5],100,10000)