function [fx,Dfx,DDfx] = fun_324_Arora(x1,x2)
syms x1 x2
fx=50*(x2-x1^2)^2+(2-x1)^2;%objective function
Dfx=[diff(fx,x1,1);diff(fx,x2,1)]%First derivative of the above function
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ];%Hessian matrix
end