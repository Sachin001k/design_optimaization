clear
y=Marquardt(@fun2,[0;0],100,20)