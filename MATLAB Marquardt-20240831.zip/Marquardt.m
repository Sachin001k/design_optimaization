function y = Marquardt(f1,x0,lamda,N)
%program to determine the minimum of a function
%f1:name of the function; it will take the name of your function
%x0:starting vectors
%N:number of iterations
%you should call as follows
%y=Marquardt(@your_function_name, starting vector, number of iterations)
syms x1 x2
[fx,Dfx,DDfx]=f1(x1,x2);%obtain your function and its first derivative in the symbolic form
eps=0.0001;
I=[1 0;0 1];
for k=1:N,
    disp("Iteration number")
    k
    x1=x0(1)
    x2=x0(2)
    fx0=eval(fx)%evaluate the numerical value of the function at x=x0
    dfx0=eval(Dfx)%evaluate the numerical value of the gradient at x=x0
    H=eval(DDfx)%evaluate the numerical value of the Hessian matrix
    s=-inv(H+lamda*I)*dfx0
    x11=x0+s
    x1=x11(1)
    x2=x11(2)  
    fx1=eval(fx)  
        if (fx1<fx0),lamda=lamda/2;end
        if (fx1>fx0),lamda=2*lamda;end
        if (norm((x0-x11),2)& norm(fx1,2))<0.001,break,end
        pause
    clc
    x0=x11
end
disp("Final value")
y=x11
 disp("Total number of iterations")
    k
