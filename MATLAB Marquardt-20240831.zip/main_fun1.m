clear
y=Marquardt(@fun1, [0;0],100, 20)