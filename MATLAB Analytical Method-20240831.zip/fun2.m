function [fx,Dfx,DDfx] = fun2(x1,x2)
syms x1 x2
fx=6*x1^2+3*x2^2+3.5*x1^2*x2+4*x1*x2+5.5*x1-2*x2;%objective function
Dfx=[diff(fx,x1,1);diff(fx,x2,1)]%First derivative of the above function
DDfx=[diff(Dfx(1),x1,1)  diff(Dfx(1),x2,1)
    diff(Dfx(1),x2,1) diff(Dfx(2),x2,1) ];%Hessian matrix
end