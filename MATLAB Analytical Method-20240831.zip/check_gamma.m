function gamma1=check_gamma(root)
n=max(size(root));
j=1;
for k=1:n,
    if (imag(root(k))==0 ),gamma1(j)=root(k);j=j+1;end
end
end