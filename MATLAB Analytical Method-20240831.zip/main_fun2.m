clear
syms x1 x2
[fx,dfx,H]=fun2(x1,x2);
eqn1=dfx(1);
eqn2=dfx(2);
x=[1;2];
S=solve([eqn1,eqn2],[x1,x2]);
x3=double(S.x1);
x3=check_gamma(x3);
x4=double(S.x2);
x4=check_gamma(x4);
n=max(size(x3));
syms x1 x2
for k=1:n,
x1=x3(k)
x2=x4(k)
H0=eval(H);
fx0=eval(fx)
    lamda=eig(H0)
        pause
    clc
end